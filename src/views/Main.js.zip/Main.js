import Alert from '@enact/sandstone/Alert';
import BodyText from '@enact/sandstone/BodyText';
import Button from '@enact/sandstone/Button';
import Input from '@enact/sandstone/Input';
import {Header, Panel} from '@enact/sandstone/Panels';
import {useState} from 'react';

import css from './Login.module.less'; // 스타일 파일 경로
import $L from '@enact/i18n/$L';

const Login = (props) => {
	const [email, setEmail] = useState('');
	const [password, setPassword] = useState('');
	const [isPopupOpen, setIsPopupOpen] = useState(false);

	const handleLogin = () => {
		if (email && password) {
			setIsPopupOpen(true); // 로그인 성공 시 알림창 열기
		} else {
			//window.alert($L('Please enter your email and password.')); // alert를 window.alert로 변경
		}
	};

	const handlePopupClose = () => {
		setIsPopupOpen(false);
	};

	// 이벤트 핸들러를 별도로 정의하여 props에 전달
	const handleEmailChange = (e) => setEmail(e.value);
	const handlePasswordChange = (e) => setPassword(e.value);

	return (
		<Panel {...props}>
			<Header title={$L('Login')} />
			<BodyText>{$L('Please enter your credentials to log in.')}</BodyText>
			<Input
				placeholder={$L('Email')}
				value={email}
				onChange={handleEmailChange} // 화살표 함수 대신 메서드 참조
				className={css.inputField}
			/>
			<Input
				placeholder={$L('Password')}
				type="password"
				value={password}
				onChange={handlePasswordChange} // 화살표 함수 대신 메서드 참조
				className={css.inputField}
			/>
			<Button onClick={handleLogin} size="small" className={css.buttonCell}>
				{$L('Login')}
			</Button>
			<Alert type="overlay" open={isPopupOpen} onClose={handlePopupClose}>
				<span>{$L('Login successful!')}</span>
				<Button
					size="small"
					className={css.buttonCell}
					onClick={handlePopupClose} // 화살표 함수 대신 메서드 참조
				>
					{$L('Close')}
				</Button>
			</Alert>
		</Panel>
	);
};

export default Login;
