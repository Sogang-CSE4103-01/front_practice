/*
import Alert from '@enact/sandstone/Alert';
import BodyText from '@enact/sandstone/BodyText';
import Button from '@enact/sandstone/Button';
import {Header, Panel} from '@enact/sandstone/Panels';
import {useMainState} from './MainState';
import css from './Main.module.less';
import $L from '@enact/i18n/$L';

const Main = props => {
	const {isPopupOpen, handlePopupClose, handleLaunchApp, videoData} = useMainState();

	return (
		<Panel {...props}>
			<Header title={$L('YouTube Clone')} />
			<BodyText>{$L('이곳은 유튜브 메인 화면을 모방한 샘플 애플리케이션입니다.')}</BodyText>
			<div className={css.videoGrid}>
				{videoData.map(video => (
					<div key={video.id} className={css.videoCard}>
						<img src={video.thumbnail} alt={video.title} className={css.thumbnail} />
						<BodyText className={css.videoTitle}>{video.title}</BodyText>
					</div>
				))}
			</div>
			<Alert type="overlay" open={isPopupOpen} onClose={handlePopupClose} closeButton={false}>
				<span>{$L('This is an alert message.')}</span>
				<buttons>
					<Button size="small" className={css.buttonCell} onClick={handleLaunchApp}>
						Launch
					</Button>
					<Button size="small" className={css.buttonCell} onClick={handlePopupClose}>
						{$L('Close')}
					</Button>
				</buttons>
			</Alert>
		</Panel>
	);
};

export default Main;
*/

import BodyText from '@enact/sandstone/BodyText';
import {Header, Panel} from '@enact/sandstone/Panels';
import {useMainState} from './MainState';
import css from './Main.module.less';
import $L from '@enact/i18n/$L';

const Main = props => {
	const {videoData} = useMainState();

	return (
		<Panel {...props}>
			<Header title={$L('YouTube Clone')} />
			<BodyText>{$L('이곳은 유튜브 메인 화면을 모방한 샘플 애플리케이션입니다.')}</BodyText>
			<div className={css.videoGrid}>
				{videoData.map(video => (
					<div key={video.id} className={css.videoCard}>
						<img src={video.thumbnail} alt={video.title} className={css.thumbnail} />
						<BodyText className={css.videoTitle}>{video.title}</BodyText>
					</div>
				))}
			</div>
		</Panel>
	);
};

export default Main;
