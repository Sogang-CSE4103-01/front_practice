import BodyText from '@enact/sandstone/BodyText';
import { Header, Panel } from '@enact/sandstone/Panels';
import { useLoginState } from './LoginState';
import css from './Login.module.less';
import $L from '@enact/i18n/$L';

const Login = () => { // props 제거
    const { username, password, handleInputChange, handleLogin } = useLoginState();

    return (
        <Panel>
            <Header title={$L('로그인')} />
            <div className={css.loginContainer}>
                <BodyText>{$L('로그인하여 계속 진행하세요.')}</BodyText>
                <input
                    type="text"
                    name="username"
                    placeholder={$L('사용자 이름')}
                    value={username}
                    onChange={handleInputChange}
                    className={css.inputField}
                />
                <input
                    type="password"
                    name="password"
                    placeholder={$L('비밀번호')}
                    value={password}
                    onChange={handleInputChange}
                    className={css.inputField}
                />
                <button onClick={handleLogin} className={css.loginButton}>
                    {$L('로그인')}
                </button>
            </div>
        </Panel>
    );
};

export default Login;
