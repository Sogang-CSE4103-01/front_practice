import { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom'; // useHistory를 useNavigate로 변경
import debugLog from '../libs/log';

export const useLoginState = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate(); // navigate 객체를 사용하여 페이지 이동

    const handleInputChange = useCallback((event) => {
        const { name, value } = event.target;
        if (name === 'username') {
            setUsername(value);
        } else if (name === 'password') {
            setPassword(value);
        }
    }, []);

    const handleLogin = useCallback(() => {
        debugLog('로그인 버튼 클릭');
        navigate('/main'); // 메인 화면으로 이동
    }, [navigate]);

    return { username, password, handleInputChange, handleLogin };
};
