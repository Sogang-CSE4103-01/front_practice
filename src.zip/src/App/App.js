import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'; // Switch를 Routes로 변경
import Login from '../views/Login';
import Main from '../views/Main';

const App = () => {
    return (
        <Router>
            <Routes>
                <Route path="/login" element={<Login />} />
                <Route path="/main" element={<Main />} />
                <Route path="/" element={<Login />} /> {/* 기본 경로를 로그인으로 설정 */}
            </Routes>
        </Router>
    );
};

export default App;
